from flask import Flask, request, jsonify
import cv2

app = Flask(__name__)

@app.route('/add', methods=['get'])
def add():
    try:
        # Open the camera
        cap = cv2.VideoCapture(0)
        
        # Check if the camera opened successfully
        if not cap.isOpened():
            return "Error: Could not open video device", 500
        
        # Read a frame from the camera
        ret, frame = cap.read()
        
        # Release the camera
        cap.release()
        
        # Check if the frame is valid
        if not ret or frame is None:
            return "Error: Could not read frame from camera", 500
        
        # Display the frame
        cv2.imshow('Adding new User', frame)
        cv2.waitKey(1)  # Add a small delay to display the image

        return "Frame captured and displayed successfully", 200
    
    except cv2.error as e:
        return f"OpenCV error: {e}", 500

if __name__ == '__main__':
    app.run(debug=True)
